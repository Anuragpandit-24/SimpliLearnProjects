Create Database vaccinationcenter;
show databases;
USE vaccinationcenter;
show tables;
select * from vaccinationcenter;
drop table vaccination_center;
desc citizens;
desc vaccinationcenter;

SELECT c.*
FROM citizens c
JOIN vaccinationcenter vc ON c.cid = vc.cid
WHERE vc.vcid = 1;

